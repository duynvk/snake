1) Hướng dẫn cài đặt
- Sử dụng ngôn ngữ lập trình C++ trên Code::Blocks
- Sử dụng vector vẽ con rắn
- Vẽ quả táo
- Tạo menu
- Vẽ các địa hình khác nhau
- Di chuyển con rắn
- Cài đặt một số phím để thực hiện các chức năng
- Cài đặt hàm kiểm tra xem đã ăn quả táo chưa
- Cài đặt hàm kiểm tra người chơi đã chơi thua chưa

2) Các chức năng chính
- Sử dụng các phím ESC,1,2,3,4,5,... để thể hiện sự lựa chon trong game
- Chơi trò chơi
	+ sử dụng 4 phím UP, DOWN, RIGHT, LEFT để di chuyển
	+ sử dụng phím SPACE để tạm dừng trò chơi
- Chọn mức độ dễ đến khó
- Xem điểm cao
- Xem hướng dẫn
- Thoát trò chơi
